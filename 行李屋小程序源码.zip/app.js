var coolsite360 = require('./coolsite/index.js');
App({
  coolsite360: coolsite360
})